# 📊 Time Series Forecasting of Monthly Product Sales

This project focuses on analyzing and forecasting monthly product sales using historical e-commerce data. It applies time series modeling to predict future demand and understand underlying trends and seasonal patterns.

---

## 📁 Dataset Overview

- **Rows**: 40,563  
- **Date Range**: January 2019 – December 2020  
- **Key Features**:  
  - `OrderDate`  
  - `total_qty_sales`  
  - `ProductCategoryNew`, `ArtistNameNew`  
  - `Selling Price`, `productListViews`, `productListClicks`

---

## 🔄 Project Workflow

### ✅ Step 1: Data Preprocessing
- Converted `OrderDate` to datetime format
- Aggregated monthly sales
- Handled missing values in click/view columns

### ✅ Step 2: Exploratory Data Analysis (EDA)
- Visualized sales trends over time
- Performed **Seasonal Decomposition** to extract trend & seasonality
- Plotted **ACF** and **PACF** to guide ARIMA parameter selection

### ✅ Step 3: Time Series Modeling
- Applied **ARIMA (1,1,1)** on monthly `total_qty_sales`
- Trained on historical data, forecasted next 12 months
- Differenced the series for stationarity

### ✅ Step 4: Evaluation
- Compared forecast with actual sales (last 12 months)
- Metrics:
  - **MAE**: 14,242  
  - **MSE**: 290,946,133  
  - **SMAPE**: ~19.8%

---

## 📈 Visual Outputs

- 📌 Line Plot: Actual vs Forecast (last 12 months)  
- 📌 ACF & PACF Plots  
- 📌 Differenced Series Visualization  
- 📌 Seasonal Decomposition  
- 📌 Full Forecast Extension Plot

---

## 🛠️ Tools & Libraries

- Python, Pandas, NumPy  
- Matplotlib, Seaborn  
- statsmodels, pmdarima  
- Jupyter Notebook

---

## 📌 Key Insights

- Sales showed strong **seasonality and trend**
- Forecasts remained stable, but underpredicted extreme variations
- ARIMA is effective, but performance can be improved using:
  - **SARIMA / SARIMAX**
  - **External regressors (price, views, clicks)**

---

## 📂 Project Structure

TimeSeries-Sales-Forecast/
├── Quantity_Analysis_TimeSeries_Structured_test.ipynb
├── Plots/
│ ├── acf_plot.png
│ ├── pacf_plot.png
│ ├── forecast_plot.png
│ ├── decomposition_plot.png
│ └── actual_vs_predicted.png
└── README.md


---

## 👤 Author

**Namrata Dolas**  
Data Science Intern | B.Tech in Electronics Engineering  
📧 namudolas5455@gmail.com  
🔗 GitHub: [Namrata-Dolas19][https://github.com/Namrata-Dolas19/Time-Series-Forecasting-of-Monthly-Product-Sales]

